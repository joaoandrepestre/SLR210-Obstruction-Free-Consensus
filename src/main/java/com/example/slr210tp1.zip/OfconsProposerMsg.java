package com.example;

public class OfconsProposerMsg {
	
	public String message;
	
	public OfconsProposerMsg(String message) {
		this.message = message;
	}

}
