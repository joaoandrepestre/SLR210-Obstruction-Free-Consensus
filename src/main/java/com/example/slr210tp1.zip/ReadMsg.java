package com.example;

public class ReadMsg {
	public String message;
	
	public ReadMsg(String message) {
		this.message = message;
	}
}
